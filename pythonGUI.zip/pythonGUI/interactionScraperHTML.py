import requests
import xml.etree.ElementTree as ET
import csv
from bs4 import BeautifulSoup
import time

def get_drug_topics(starting_letter=None):
    """
    Fetch drug topics from MedlinePlus XML.
    
    Args:
        starting_letter: Filter drugs by starting letter (optional)
    
    Returns:
        List of tuples (title, url)
    """
    # Use a valid date - adjust as needed
    xml_url = "https://medlineplus.gov/xml/mplus_topics_2024-10-01.xml"
    
    print("Downloading XML...")
    try:
        r = requests.get(xml_url, timeout=30)
        r.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Error downloading XML: {e}")
        return []
    
    print("Parsing XML...")
    try:
        root = ET.fromstring(r.content)
    except ET.ParseError as e:
        print(f"Error parsing XML: {e}")
        return []
    
    drug_topics = []
    for topic in root.findall("health-topic"):
        title = topic.get("title")
        url = topic.get("url")
        
        if not title or not url:
            continue
            
        # Get groups for this topic
        groups = [g.text for g in topic.findall("group") if g.text]
        
        # Filter for drug therapy
        if "Drug Therapy" in groups or "Medicines" in groups:
            # Optional: filter by starting letter
            if starting_letter is None or title.upper().startswith(starting_letter.upper()):
                drug_topics.append((title, url))
    
    return drug_topics

def extract_side_effects(url):
    """
    Fetch a drug page and attempt to extract side effect information.
    
    Args:
        url: URL of the MedlinePlus drug page
    
    Returns:
        String containing side effects or error message
    """
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        
        soup = BeautifulSoup(r.content, 'html.parser')
        
        # Look for side effects section
        # MedlinePlus typically has sections with specific IDs or headers
        side_effects = []
        
        # Try to find section with "side effect" in heading
        for heading in soup.find_all(['h2', 'h3', 'h4']):
            if heading and 'side effect' in heading.get_text().lower():
                # Get the next sibling elements (usually <p> or <ul>)
                next_elem = heading.find_next_sibling()
                while next_elem and next_elem.name in ['p', 'ul', 'ol']:
                    side_effects.append(next_elem.get_text(strip=True))
                    next_elem = next_elem.find_next_sibling()
                    if next_elem and next_elem.name in ['h2', 'h3', 'h4']:
                        break
        
        if side_effects:
            return " ".join(side_effects)
        else:
            return "Side effects section not found"
            
    except requests.exceptions.RequestException as e:
        return f"Error fetching page: {e}"
    except Exception as e:
        return f"Error parsing page: {e}"

def main():
    """Main function to orchestrate the scraping."""
    
    # Get drug name from user
    drug_letter = input("Enter starting letter for drugs (or press Enter for all): ").strip()
    drug_letter = drug_letter if drug_letter else None
    
    # Fetch drug topics
    print("\nFetching drug topics from MedlinePlus...")
    drug_topics = get_drug_topics(drug_letter)
    
    if not drug_topics:
        print("No drug topics found.")
        return
    
    print(f"Found {len(drug_topics)} drug topics")
    
    # Ask user if they want to fetch side effects (can be slow)
    fetch_details = input("\nFetch side effects for each drug? (y/n): ").strip().lower()
    
    results = []
    
    if fetch_details == 'y':
        print("\nFetching side effects (this may take a while)...")
        for i, (title, url) in enumerate(drug_topics, 1):
            print(f"Processing {i}/{len(drug_topics)}: {title}")
            side_effects = extract_side_effects(url)
            results.append((title, url, side_effects))
            
            # Be respectful - add delay between requests
            time.sleep(1)
    else:
        results = [(title, url, "Not fetched") for title, url in drug_topics]
    
    # Write to CSV
    letter_suffix = f"_{drug_letter}" if drug_letter else "_all"
    csv_path = f"medlineplus_drugs{letter_suffix}.csv"
    
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Drug Name", "URL", "Side Effects"])
        writer.writerows(results)
    
    print(f"\n✓ Saved {len(results)} entries to {csv_path}")

if __name__ == "__main__":
    main()
